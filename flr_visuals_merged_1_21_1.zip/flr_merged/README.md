# FLR Visuals — merged edition

NeoForge 1.21.1 client-side cosmetic visuals, объединяющие идеи загруженного FLR Visuals JAR и новой оптимизированной основы.

## Added
- procedural Halo / Wings / Cape;
- Aura / Trail / Hit Sparks;
- five themes: Purple, Cyan, Pink, Gold, Green;
- dark FLR menu;
- Pretty Fog-ready configuration;
- particle budget to prevent particle spam;
- distance culling;
- master switch;
- GitHub Actions build;
- original supplied FLR logo kept in assets.

## Controls
- O — menu
- P — master toggle

Java 21 / Minecraft 1.21.1 / NeoForge.
