package dev.flr.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;

/** Lightweight cosmetic layer. Geometry is procedural: no texture atlas lookups. */
public final class CosmeticsLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public CosmeticsLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) { super(parent); }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int light, AbstractClientPlayer p,
                       float limbSwing, float limbSwingAmount, float partialTick,
                       float ageInTicks, float netHeadYaw, float headPitch) {
        Minecraft mc = Minecraft.getInstance();
        if (!Config.master || p.isInvisible() || mc.player != p) return;

        double d = p.distanceToSqr(mc.player);
        if (d > Config.maxDistance * Config.maxDistance) return;

        VertexConsumer out = buffers.getBuffer(RenderType.debugQuads());
        Matrix4f m = pose.last().pose();
        int c = Config.color();
        int bright = withAlpha(c, 230);
        int soft = withAlpha(c, 105);
        float phase = (p.tickCount + partialTick) * 0.08f;

        if (Config.cape) cape(out, m, phase, c, soft);
        if (Config.wings) wings(out, m, phase, c, bright);
        if (Config.halo) halo(out, m, phase, soft, bright);
    }

    private static void halo(VertexConsumer v, Matrix4f m, float phase, int soft, int bright) {
        float y = -0.64f + Mth.sin(phase * .75f) * .02f;
        final int n = 24;
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            double b = (i + 1) * Math.PI * 2 / n;
            ring(v, m, a, b, .20f, .34f, y, soft);
            ring(v, m, a, b, .225f, .30f, y + .004f, bright);
        }
    }

    private static void wings(VertexConsumer v, Matrix4f m, float phase, int c, int glow) {
        float flap = Mth.sin(phase * 1.8f) * .10f;
        for (int side : new int[]{-1, 1}) {
            for (int i = 0; i < 5; i++) {
                float x0 = side * (.20f + i * .13f);
                float x1 = side * (.36f + i * .16f);
                float y = -.15f - i * .035f + flap * side;
                quad(v, m, x0, y, .10f, x1, y + .10f, .12f, withAlpha(c, 175));
            }
        }
    }

    private static void cape(VertexConsumer v, Matrix4f m, float phase, int c, int alpha) {
        float sway = Mth.sin(phase * 1.2f) * .04f;
        quad(v, m, -.28f, .28f, sway, .28f, .28f, sway, withAlpha(c, 70));
        quad(v, m, -.25f, -.35f, sway, .25f, -.35f, sway, withAlpha(c, 45));
    }

    private static void ring(VertexConsumer v, Matrix4f m, double a, double b,
                             float r0, float r1, float y, int color) {
        float c0 = (float)Math.cos(a), s0 = (float)Math.sin(a);
        float c1 = (float)Math.cos(b), s1 = (float)Math.sin(b);
        vertex(v,m,c0*r0,y,s0*r0,color); vertex(v,m,c0*r1,y,s0*r1,color);
        vertex(v,m,c1*r1,y,s1*r1,color); vertex(v,m,c1*r0,y,s1*r0,color);
    }

    private static void quad(VertexConsumer v, Matrix4f m, float x0,float y0,float z0,
                             float x1,float y1,float z1,int color) {
        vertex(v,m,x0,y0,z0,color); vertex(v,m,x1,y1,z1,color);
        vertex(v,m,x1,y0,z1,color); vertex(v,m,x0,y1,z0,color);
    }

    private static void vertex(VertexConsumer v, Matrix4f m, float x,float y,float z,int color) {
        v.addVertex(m, x, y, z).setColor(color).setUv(0,0).setLight(0xF000F0).setNormal(0,1,0);
    }

    private static int withAlpha(int rgb, int alpha) { return (rgb & 0xFFFFFF) | (alpha << 24); }
}
