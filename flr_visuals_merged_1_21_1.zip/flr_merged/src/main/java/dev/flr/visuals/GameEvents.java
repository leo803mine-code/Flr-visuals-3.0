package dev.flr.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

@EventBusSubscriber(modid = FlrVisuals.MOD_ID, value = Dist.CLIENT)
public final class GameEvents {
    private static int tick;
    private static Vec3 lastPos;
    private static int budget;

    private GameEvents() {}

    @SubscribeEvent
    public static void tick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;

        while (FlrKeys.MASTER.consumeClick()) Config.master = !Config.master;
        while (FlrKeys.MENU.consumeClick()) mc.setScreen(new CosmeticsScreen());

        tick++;
        budget = Config.particleBudget;
        if (!Config.master || Config.noRenderParticles) {
            lastPos = p.position();
            return;
        }

        float t = tick * 0.08f;
        if (Config.halo && tick % 2 == 0) {
            for (int i = 0; i < 8 && budget > 0; i++) {
                double a = t + i * Math.PI * 2.0 / 8.0;
                spawn(mc, p.getX() + Math.cos(a) * 0.42, p.getY() + 2.42,
                        p.getZ() + Math.sin(a) * 0.42, 0, 0.006, 0);
            }
        }
        if (Config.aura && tick % 3 == 0 && budget > 0) {
            double a = t * 0.8;
            spawn(mc, p.getX() + Math.cos(a) * 0.48,
                    p.getY() + 0.9 + Math.sin(t) * 0.35,
                    p.getZ() + Math.sin(a) * 0.48, 0, 0.004, 0);
        }
        if (Config.trail && lastPos != null && p.position().distanceToSqr(lastPos) > 0.01 && budget > 0) {
            Vec3 q = lastPos.lerp(p.position(), 0.45);
            spawn(mc, q.x, q.y + 0.65, q.z, 0, 0.008, 0);
        }
        if (Config.hitSparks && p.swinging && p.attackAnim > 0.1f && tick % 4 == 0) {
            for (int i = 0; i < 3 && budget > 0; i++) {
                double a = t * 2 + i * Math.PI * 2 / 3;
                spawn(mc, p.getX() + Math.cos(a) * 0.65, p.getY() + 1.0,
                        p.getZ() + Math.sin(a) * 0.65, Math.cos(a) * .015, .015, Math.sin(a) * .015);
            }
        }
        lastPos = p.position();
    }

    private static void spawn(Minecraft mc, double x, double y, double z, double vx, double vy, double vz) {
        if (budget-- <= 0) return;
        mc.level.addParticle(ParticleTypes.END_ROD, x, y, z, vx, vy, vz);
    }
}
