package dev.flr.visuals;

import net.neoforged.fml.common.Mod;

@Mod(FlrVisuals.MOD_ID)
public final class FlrVisuals {
    public static final String MOD_ID = "flrvisuals";

    public FlrVisuals() {
    }
}
