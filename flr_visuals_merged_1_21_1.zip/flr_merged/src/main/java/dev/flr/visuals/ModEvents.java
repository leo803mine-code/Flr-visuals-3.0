package dev.flr.visuals;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;

@EventBusSubscriber(modid = FlrVisuals.MOD_ID, value = Dist.CLIENT)
public final class ModEvents {
    private ModEvents() {}

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent event) {
        event.register(FlrKeys.MENU);
        event.register(FlrKeys.MASTER);
    }
}
