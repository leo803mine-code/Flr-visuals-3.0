package dev.flr.visuals;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.neoforged.neoforge.client.settings.KeyConflictContext;

public final class FlrKeys {
    public static final KeyMapping MENU = new KeyMapping(
            "key.flrvisuals.menu", InputConstants.Type.KEYSYM, InputConstants.KEY_O,
            "key.categories.flrvisuals");
    public static final KeyMapping MASTER = new KeyMapping(
            "key.flrvisuals.master", InputConstants.Type.KEYSYM, InputConstants.KEY_P,
            "key.categories.flrvisuals");

    private FlrKeys() {}
}
